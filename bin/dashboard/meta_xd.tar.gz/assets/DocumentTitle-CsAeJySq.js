import{d as t,bC as r}from"./index-CxY9iUr8.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
